# backend/modules/gestion_productiva/produccion/services.py

from sqlalchemy.orm import Session
from .models import (
    GestionProductivaCabecera,
    GestionProductivaEntrada,
    GestionProductivaSalida,
    GestionProductivaResultado,
    Molde
)


def obtener_lista_moldes(db: Session):
    moldes = db.query(Molde).order_by(Molde.id_molde.desc()).all()

    resultado = []
    for molde in moldes:
        resultado.append({
            "id_molde": molde.id_molde,
            "nombre": molde.nombre,
            "descripcion": molde.descripcion,
            "numero_camadas": molde.numero_camadas,
            "numero_envases": molde.numero_envases,
            "numero_gruesas": molde.numero_gruesas
        })

    return resultado


def obtener_registros_produccion(db: Session, skip: int = 0, limit: int = 50):
    """
    Obtiene el listado de movimientos de producción paginado (50 en 50),
    extrayendo solo los campos específicos de Cabecera y Resultado
    necesarios para la vista principal del frontend.
    """
    registros = db.query(
        GestionProductivaCabecera.id_cabecera,
        GestionProductivaCabecera.fecha,
        GestionProductivaCabecera.turno,
        GestionProductivaCabecera.tecnico,
        GestionProductivaCabecera.total_gruesas,
        GestionProductivaResultado.total_gruesas_lisas,
        GestionProductivaResultado.total_gruesas_decoradas,
        GestionProductivaResultado.eficiencia_productiva,
        GestionProductivaResultado.deficiencia_productiva
    ).join(
        GestionProductivaResultado,
        GestionProductivaCabecera.id_cabecera == GestionProductivaResultado.id_cabecera,
        isouter=True
    ).order_by(
        GestionProductivaCabecera.id_cabecera.desc()
    ).offset(skip).limit(limit).all()

    resultado = []
    for reg in registros:
        resultado.append({
            "id_cabecera": reg.id_cabecera,
            "fecha": reg.fecha,
            "turno": reg.turno,
            "tecnico": reg.tecnico,
            "total_gruesas": reg.total_gruesas,
            "total_gruesas_lisas": reg.total_gruesas_lisas,
            "total_gruesas_decoradas": reg.total_gruesas_decoradas,
            "eficiencia_productiva": reg.eficiencia_productiva,
            "deficiencia_productiva": reg.deficiencia_productiva
        })

    return resultado


def obtener_produccion_por_id(db: Session, id_cabecera: int):
    """
    Consulta un registro específico por su ID.
    Devuelve la cabecera con sus relaciones (entradas, salidas, resultado).
    """
    cabecera = db.query(GestionProductivaCabecera)\
                 .filter(GestionProductivaCabecera.id_cabecera == id_cabecera)\
                 .first()

    if not cabecera:
        return None

    # Agrupar las entradas por máquina para armar la respuesta
    cabecera.maquina1 = [e for e in cabecera.entradas if e.maquina == 1]
    cabecera.maquina2 = [e for e in cabecera.entradas if e.maquina == 2]
    cabecera.maquina3 = [e for e in cabecera.entradas if e.maquina == 3]
    cabecera.maquina4 = [e for e in cabecera.entradas if e.maquina == 4]

    return cabecera


def crear_registro_produccion(db: Session, datos):
    """
    Registra la cabecera, los detalles de entrada por máquina (gestion_productiva_entrada),
    las salidas por molde y el resultado consolidado en una sola transacción.
    """
    # 1. Crear la cabecera del turno
    nueva_cabecera = GestionProductivaCabecera(
        fecha=datos.fecha,
        turno=datos.turno,
        tecnico=datos.tecnico,
        cant_envases_d1=datos.cant_envases_d1,
        cant_envases_d2=datos.cant_envases_d2,
        cant_envases_d3=datos.cant_envases_d3,
        cant_envases_d4=datos.cant_envases_d4,
        total_envases=datos.total_envases,
        total_gruesas=datos.total_gruesas
    )
    db.add(nueva_cabecera)
    db.flush()  # Genera el id_cabecera

    # 2. Insertar detalles de entrada por máquina
    maquinas = {
        1: datos.maquina1,
        2: datos.maquina2,
        3: datos.maquina3,
        4: datos.maquina4
    }
    for numero_maquina, detalles in maquinas.items():
        for detalle in detalles:
            nueva_entrada = GestionProductivaEntrada(
                id_cabecera=nueva_cabecera.id_cabecera,
                maquina=numero_maquina,
                id_molde=detalle.id_molde,
                cant_envases=detalle.cant_envases
            )
            db.add(nueva_entrada)

    # 3. Insertar salidas por molde
    for salida_data in datos.salidas:
        nueva_salida = GestionProductivaSalida(
            id_cabecera=nueva_cabecera.id_cabecera,
            modelo_molde=salida_data.modelo_molde,
            total_paletas=salida_data.total_paletas,
            cant_paletas_lisas=salida_data.cant_paletas_lisas,
            cant_camadas_lisas=salida_data.cant_camadas_lisas,
            cant_envases_lisas=salida_data.cant_envases_lisas,
            cant_gruesas_lisas=salida_data.cant_gruesas_lisas,
            cant_paletas_decoradas=salida_data.cant_paletas_decoradas,
            cant_camadas_decoradas=salida_data.cant_camadas_decoradas,
            cant_envases_decoradas=salida_data.cant_envases_decoradas,
            cant_gruesas_decoradas=salida_data.cant_gruesas_decoradas
        )
        db.add(nueva_salida)

    # 4. Crear el consolidado final
    nuevo_resultado = GestionProductivaResultado(
        id_cabecera=nueva_cabecera.id_cabecera,
        total_gruesas_lisas=datos.resultado.total_gruesas_lisas,
        total_gruesas_decoradas=datos.resultado.total_gruesas_decoradas,
        eficiencia_productiva=datos.resultado.eficiencia_productiva,
        deficiencia_productiva=datos.resultado.deficiencia_productiva,
        observaciones=datos.resultado.observaciones
    )
    db.add(nuevo_resultado)

    db.commit()
    db.refresh(nueva_cabecera)
    return obtener_produccion_por_id(db, nueva_cabecera.id_cabecera)


def actualizar_registro_produccion(db: Session, id_cabecera: int, datos):
    """
    Actualiza la cabecera, reemplaza los detalles de entrada por máquina,
    sincroniza las salidas y actualiza el resultado.
    """
    cabecera_actual = db.query(GestionProductivaCabecera)\
                        .filter(GestionProductivaCabecera.id_cabecera == id_cabecera)\
                        .first()

    if not cabecera_actual:
        return None

    # 1. Actualizar cabecera
    cabecera_actual.fecha = datos.fecha
    cabecera_actual.turno = datos.turno
    cabecera_actual.tecnico = datos.tecnico
    cabecera_actual.cant_envases_d1 = datos.cant_envases_d1
    cabecera_actual.cant_envases_d2 = datos.cant_envases_d2
    cabecera_actual.cant_envases_d3 = datos.cant_envases_d3
    cabecera_actual.cant_envases_d4 = datos.cant_envases_d4
    cabecera_actual.total_envases = datos.total_envases
    cabecera_actual.total_gruesas = datos.total_gruesas

    # 2. Reemplazar detalles de entrada (borrar y reinsertar)
    db.query(GestionProductivaEntrada)\
      .filter(GestionProductivaEntrada.id_cabecera == id_cabecera)\
      .delete()

    maquinas = {
        1: datos.maquina1,
        2: datos.maquina2,
        3: datos.maquina3,
        4: datos.maquina4
    }
    for numero_maquina, detalles in maquinas.items():
        for detalle in detalles:
            nueva_entrada = GestionProductivaEntrada(
                id_cabecera=id_cabecera,
                maquina=numero_maquina,
                id_molde=detalle.id_molde,
                cant_envases=detalle.cant_envases
            )
            db.add(nueva_entrada)

    # 3. Sincronizar salidas
    db.query(GestionProductivaSalida)\
      .filter(GestionProductivaSalida.id_cabecera == id_cabecera)\
      .delete()

    for salida_data in datos.salidas:
        nueva_salida = GestionProductivaSalida(
            id_cabecera=id_cabecera,
            modelo_molde=salida_data.modelo_molde,
            total_paletas=salida_data.total_paletas,
            cant_paletas_lisas=salida_data.cant_paletas_lisas,
            cant_camadas_lisas=salida_data.cant_camadas_lisas,
            cant_envases_lisas=salida_data.cant_envases_lisas,
            cant_gruesas_lisas=salida_data.cant_gruesas_lisas,
            cant_paletas_decoradas=salida_data.cant_paletas_decoradas,
            cant_camadas_decoradas=salida_data.cant_camadas_decoradas,
            cant_envases_decoradas=salida_data.cant_envases_decoradas,
            cant_gruesas_decoradas=salida_data.cant_gruesas_decoradas
        )
        db.add(nueva_salida)

    # 4. Actualizar resultado
    if cabecera_actual.resultado:
        cabecera_actual.resultado.total_gruesas_lisas = datos.resultado.total_gruesas_lisas
        cabecera_actual.resultado.total_gruesas_decoradas = datos.resultado.total_gruesas_decoradas
        cabecera_actual.resultado.eficiencia_productiva = datos.resultado.eficiencia_productiva
        cabecera_actual.resultado.deficiencia_productiva = datos.resultado.deficiencia_productiva
        cabecera_actual.resultado.observaciones = datos.resultado.observaciones

    db.commit()
    return obtener_produccion_por_id(db, id_cabecera)